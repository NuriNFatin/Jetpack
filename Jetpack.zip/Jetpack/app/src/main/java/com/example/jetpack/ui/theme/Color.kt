package com.example.jetpack.ui.theme

import androidx.compose.ui.graphics.Color

val SoftBlue = Color(0xFFBAE6FD)
val Blue = Color(0xFF0284C7)
val BlueHard = Color(0xFF082F49)